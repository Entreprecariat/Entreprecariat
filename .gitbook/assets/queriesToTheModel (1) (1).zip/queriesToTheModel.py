import pandas as pd
from gensim.models import KeyedVectors
from pprint import pprint
'''
a = pd.read_csv("corpus/tweets/entreprecariat.csv")
tweet = a["Tweet"]
for t in tweet: 
    t = re.sub(r"https:\/\/t\.co\/.*", " ", t)
    print(t)
'''
wv = KeyedVectors.load("vectors/word2vec.wordvectors", mmap='r')

#SIMILARITIES

pprint(wv.most_similar("entreprecariat"))

print("The similarity between PRECARIAT and YOUTH is:", wv.similarity("precariat", "youth"))
print("The similarity between WORK and YOUTH is:", wv.similarity("work", "youth"))

#ANALOGY DIFFERENCE

#which word is to work as youth is to precariat?
print(wv.most_similar(positive=["work", "youth"], negative=["precariat"], topn=3))
#which word is to employed as unpaid is to precariat?
print(wv.most_similar(positive=["employed", "unpaid"], negative=["precariat"], topn=3))

#which word is to employed as unpaid is to precariat?
print(wv.most_similar(positive=["entreprecariat", "precariat"], negative=["facebook"], topn=3))

#which word is to employed as unpaid is to precariat?
print(wv.most_similar(positive=["utopia", "decision"], negative=["conscious"], topn=3))